# Simon-Game
Another one to my collection of front-end web games! This game is extremely basic, and you just press any key to start the game which
triggers the game mechanism that beeps one of the four colored boxes on the screen. The beeped box goes into an array which stores 
the sequence of color buttons to be pressed. The user then has to copy that particular sequence and once the full sequence has been copied
another colored button gets added to that sequence making the sequence longer as each level progresses. The user can make upto as many stages
as they are able to.


I added sounds to the game upon button pressing and gameover sound when the player loses the game. All the sound files are available in the sounds folder.

Run Instructions: You can either download the files and open index.html with a browser, or you can access this link to play the game
online: https://msalman81.github.io/Simon-Game/

Here is a sneakpeak from the game!

![Capture](https://user-images.githubusercontent.com/46281169/60651872-8a8c2480-9e60-11e9-9e6f-feeb76e6e159.PNG)

